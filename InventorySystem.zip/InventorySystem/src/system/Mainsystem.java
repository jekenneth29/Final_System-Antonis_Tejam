/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package system;

/**
 *
 * @author Taki
 */
public class Mainsystem {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new LogIn().setVisible(true);  // Replace with your actual class name
        });
    }
    
}
